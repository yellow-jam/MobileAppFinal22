package com.example.ukids

data class ItemModel(val parkNm:String, val roadAdd:String, val parkType:String)
