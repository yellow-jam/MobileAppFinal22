package com.example.ukids

data class PageListModel(val data:MutableList<ItemModel>?)